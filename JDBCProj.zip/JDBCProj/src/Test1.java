import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dao.ProductDAOImpl;
import com.vo.Product;

public class Test1 {
	
	public static List<Product> getProducts(){
		
		List<Product> productsList = new ArrayList<>();
		
		String selectQuery = "select * from test.product";
		
		 
		
	     try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root")) {
	 		
	    	 
	    	 //Step 2 : Establish the connection
	    	 
	    	 
	    	 Statement statement = connection.createStatement();
	    	 
	    	 ResultSet resultSet = statement.executeQuery(selectQuery);
	    	 
	    	 while(resultSet.next()){
	    		 
	    		 Product product  = new Product();
	    		 
	    		 product.setId(resultSet.getInt("product_id"));
	    		 product.setName(resultSet.getString("product_name"));
	    		 product.setDescription(resultSet.getString("product_description"));
	    		 product.setPrice(resultSet.getFloat("product_price"));
	    		 
	    		 productsList.add(product);
	    	 }
	    	 
	    	 resultSet.close();
	    	 
	    	 statement.close(); 	 
	    	 
	    	 
	     }catch(Exception e){
	    	 e.printStackTrace();
	     }
		
	     return productsList;
	}

	public static void addProduct(Product product){
		
//		String insertQuery = "insert into test.product(product_id,product_name,product_price,product_description) "
//				+ "values(177,'Dairy',5,'Executive Dairy')";
		String insertQuery = "insert into test.product(product_id,product_name,product_price,product_description) "
				+ "values(?,?,?,?)";
		                //1,2,3,4
		

     try{
		
    	 //Step 1 : loading the jdbc drivers
    	 Class.forName("org.gjt.mm.mysql.Driver");
    	 
    	 //Class.forName ("oracle.jdbc.driver.OracleDriver");
    	 
    	 //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    	 
    	 //Step 2 : Establish the connection
    	 Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
    	 
    	 //Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sid","username","password");
    	 
    	 //Connection connection = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=AdventureWorks;integratedSecurity=true;","username","password");

    	 
    	 //Statement statement = connection.createStatement();
    	 PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
    	 
    	 //int noOfrows = statement.executeUpdate(insertQuery);
    	 
    	 preparedStatement.setInt(1,product.getId());
    	 preparedStatement.setString(2,product.getName());
    	 preparedStatement.setFloat(3,product.getPrice());
    	 preparedStatement.setString(4,product.getDescription());
    	 
    	 int noOfrows = preparedStatement.executeUpdate();
    	 
    	 if(noOfrows == 1){
    		 System.out.println("Record added successfully");
    	 }
    	 
    	 preparedStatement.close();
    	 
    	 connection.close();
    	 
     }catch(Exception e){
    	 e.printStackTrace();
     }

}


	
	public static void main(String[] args) {
		
		ProductDAOImpl productDAOImpl = new ProductDAOImpl();	
		
		
		List<Product> productsList = productDAOImpl.getProducts();
		
		for (Product product : productsList) {
			
			System.out.println("ProductId   : "+product.getId());
			System.out.println("ProductName : "+product.getName());
			System.out.println("ProductPrice: "+product.getPrice());
			System.out.println("ProductDesc : "+product.getDescription());
			System.out.println();
		}
		
//		Product product = new Product(178,"Coffee Mug",10,"Gift Article");
//		
//		addProduct(product);
		
	}

}
