package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vo.Product;

public class ProductDAOImpl extends BaseDAO implements IProductDAO{
	
	
	@Override
	public boolean addProduct(Product product) {
		
		
		String insertQuery = "insert into test.product(product_id,product_name,product_price,product_description) "
				+ "values(?,?,?,?)";

		
		try(Connection connection = getConnection()){
			
			 PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
	    	 
	    	 //int noOfrows = statement.executeUpdate(insertQuery);
	    	 
	    	 preparedStatement.setInt(1,product.getId());
	    	 preparedStatement.setString(2,product.getName());
	    	 preparedStatement.setFloat(3,product.getPrice());
	    	 preparedStatement.setString(4,product.getDescription());
	    	 
	    	 int noOfrows = preparedStatement.executeUpdate();
	    	 
	    	 if(noOfrows == 1){
	    		 System.out.println("Record added successfully");
	    		 return true;
	    	 }
	    	 
	    	 preparedStatement.close();

			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	@Override
	public boolean deleteProduct(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Product fetchProductById(int id) {
		
		Product product = null;
		
		String selectQuery = "select * from test.product where product_id=?";		 
		
	     try(Connection connection = getConnection()) {	    	 
	    	 
	    	 PreparedStatement statement = connection.prepareStatement(selectQuery);
	    	 
	    	 statement.setInt(1,id);
	    	 
	    	 ResultSet resultSet = statement.executeQuery();
	    	 
	    	 if(resultSet.next()){
	    		 
	    		 product  = new Product();
	    		 
	    		 product.setId(resultSet.getInt("product_id"));
	    		 product.setName(resultSet.getString("product_name"));
	    		 product.setDescription(resultSet.getString("product_description"));
	    		 product.setPrice(resultSet.getFloat("product_price"));    		 
	    		
	    	 }
	    	 
	    	 resultSet.close();	    	 
	    	 statement.close(); 	 	    	 
	    	 
	     }catch(Exception e){
	    	 e.printStackTrace();
	     }
		
	     return product;

	}

	@Override
	public List<Product> getProducts() {
		List<Product> productsList = new ArrayList<>();
		
		String selectQuery = "select * from test.product";		 
		
	     try(Connection connection = getConnection()) {	    	 
	    	 
	    	 Statement statement = connection.createStatement();
	    	 
	    	 ResultSet resultSet = statement.executeQuery(selectQuery);
	    	 
	    	 while(resultSet.next()){
	    		 
	    		 Product product  = new Product();
	    		 
	    		 product.setId(resultSet.getInt("product_id"));
	    		 product.setName(resultSet.getString("product_name"));
	    		 product.setDescription(resultSet.getString("product_description"));
	    		 product.setPrice(resultSet.getFloat("product_price"));
	    		 
	    		 productsList.add(product);
	    	 }
	    	 
	    	 resultSet.close();	    	 
	    	 statement.close(); 	 	    	 
	    	 
	     }catch(Exception e){
	    	 e.printStackTrace();
	     }
		
	     return productsList;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

}
