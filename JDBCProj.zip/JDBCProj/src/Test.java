import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class Test {
	
	public static void createProcedureRaisePrice() throws SQLException {
	    
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root", "root");
		
	    String createProcedure = null;

	    String queryDrop = "DROP PROCEDURE IF EXISTS RAISE_PRICE";

	    createProcedure =
	        "create procedure coffeeshop.RAISE_PRICE(IN coffeeName varchar(32), IN maximumPercentage float, INOUT newPrice numeric(10,2)) " +
	          "begin " +
	            "main: BEGIN " +
	              "declare maximumNewPrice numeric(10,2); " +
	              "declare oldPrice numeric(10,2); " +
	              "select COFFEES.PRICE into oldPrice " +
	                "from COFFEES " +
	                "where COFFEES.COF_NAME = coffeeName; " +
	              "set maximumNewPrice = oldPrice * (1 + maximumPercentage); " +
	              "if (newPrice > maximumNewPrice) " +
	                "then set newPrice = maximumNewPrice; " +
	              "end if; " +
	              "if (newPrice <= oldPrice) " +
	                "then set newPrice = oldPrice;" +
	                "leave main; " +
	              "end if; " +
	              "update COFFEES " +
	                "set COFFEES.PRICE = newPrice " +
	                "where COFFEES.COF_NAME = coffeeName; " +
	              "select newPrice; " +
	            "END main; " +
	          "end";
	    
	    Statement stmt = null;
	    Statement stmtDrop = null;

	    try {
	      System.out.println("Calling DROP PROCEDURE");
	      stmtDrop = con.createStatement();
	      stmtDrop.execute(queryDrop);
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    } finally {
	      if (stmtDrop != null) { stmtDrop.close(); }
	    }


	    try {
	      stmt = con.createStatement();
	      stmt.executeUpdate(createProcedure);
	    } catch (SQLException e) {
	    	e.printStackTrace(); 
	    } finally {
	      if (stmt != null) { stmt.close(); }
	    }

	    
	  }
	
	public static void createProcedureGetSupplierOfCoffee() throws SQLException {

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coffeeshop","root", "root");		
		
	    String createProcedure = null;

	    String queryDrop = "DROP PROCEDURE IF EXISTS coffeeshop.GET_SUPPLIER_OF_COFFEE";

	    createProcedure =
	        "create procedure coffeeshop.GET_SUPPLIER_OF_COFFEE(IN coffeeName varchar(32), OUT supplierName varchar(40)) " +
	          "begin " +
	            "select SUPPLIERS.SUP_NAME into supplierName " +
	              "from SUPPLIERS, COFFEES " +
	              "where SUPPLIERS.SUP_ID = COFFEES.SUP_ID " +
	              "and coffeeName = COFFEES.COF_NAME; " +
	            "select supplierName; " +
	          "end";
	    Statement stmt = null;
	    
	    

	    try {
	      stmt = con.createStatement();
	     // stmt.execute(queryDrop);
	     stmt.execute(createProcedure);
	      
	      
	      
	    } catch (SQLException e) {
	      e.printStackTrace();
	    } finally {
	      if (stmt != null) { stmt.close(); }
	    }
	  }
	  

	public static void main(String[] args) throws SQLException {	
		
		
		//createProcedureRaisePrice();
		
		//createProcedureGetSupplierOfCoffee();

		//Calling StoredProcedure
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coffeeshop","root", "root");		
		
		CallableStatement callableStatement = con.prepareCall("call coffeeshop.GET_SUPPLIER_OF_COFFEE(?,?)");
		
		callableStatement.setString(1,"colombian");
		callableStatement.registerOutParameter(2,Types.VARCHAR);		
		
		callableStatement.executeUpdate();
		
		System.out.println("SupplierName : "+callableStatement.getString(2));

		con.close();
		
	}

}
