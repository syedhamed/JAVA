package com.dao;

import java.util.List;

import com.vo.Product;

public interface IProductDAO {
	
	boolean addProduct(Product product);
	Product fetchProductById(int id);
	List<Product> fetchProducts();
	boolean deleteProduct(int id);
	boolean updateProduct(Product product);

}
