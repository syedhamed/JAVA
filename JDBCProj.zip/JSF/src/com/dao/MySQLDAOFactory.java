package com.dao;

import com.dao.impl.ProductDAO;

//Concrete Factory class
public class MySQLDAOFactory extends DAOFactory{
	
	public IProductDAO getProductDAO() {
		return new ProductDAO();
	}

}
