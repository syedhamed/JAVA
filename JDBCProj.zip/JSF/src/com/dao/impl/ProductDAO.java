package com.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dao.IProductDAO;
import com.vo.Product;

public class ProductDAO extends BaseDAO implements IProductDAO{

	@Override
	public boolean addProduct(Product product) {

		String insertQuery = "insert into test.product(product_id,product_name,product_price,product_description)"
				+ " values(?,?,?,?)";
		                 //1,2,3,4

		
		try(Connection connection = getConnection()){
		
			
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			
			preparedStatement.setInt(1,product.getId());
			preparedStatement.setString(2,product.getName());
			preparedStatement.setFloat(3,product.getPrice());
			preparedStatement.setString(4,product.getDescription());
			
			int rowsUpdated = preparedStatement.executeUpdate();
			
			if(rowsUpdated == 1){
				System.out.println("Record added successfully");
				return true;
			}
	
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Product fetchProductById(int id) {
		// TODO Auto-generated method stub
	Product product = null;
		
		String selectQuery  = "select * from test.product where product_id=?";
		
		try(Connection connection = getConnection();PreparedStatement statement = connection.prepareStatement(selectQuery)){
			
			statement.setInt(1,id);
			
			ResultSet resultSet = statement.executeQuery();
									
			if(resultSet.next()) {				
				product = new Product();				
				product.setId(resultSet.getInt("product_id"));
				product.setName(resultSet.getString("product_name"));
				product.setPrice(resultSet.getFloat("product_price"));
				product.setDescription(resultSet.getString("product_description"));		
				
			}
			
			resultSet.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return product;

	}

	@Override
	public List<Product> fetchProducts() {

		ArrayList<Product> productsList = new ArrayList<>();
				
		try(Connection connection = getConnection()){
			
			String selectQuery = "select * from test.product";
			
			Statement statement = connection.createStatement();
			
			ResultSet resultSet = statement.executeQuery(selectQuery);
			
			while(resultSet.next()){
				Product product = new Product();
				product.setId(resultSet.getInt("product_id"));
				product.setName(resultSet.getString("product_name"));
				product.setPrice(resultSet.getFloat("product_price"));
				product.setDescription(resultSet.getString("product_description"));
				
				productsList.add(product);
			}
			
		}catch (Exception e) {

			e.printStackTrace();
		}
		
		return productsList;

	}

	@Override
	public boolean deleteProduct(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
