package com.dao;

//Abstract factory
public abstract class DAOFactory {
			
	public abstract IProductDAO getProductDAO();
	
	public static DAOFactory getDAOFactory(){
		return new MySQLDAOFactory();
	}

}
