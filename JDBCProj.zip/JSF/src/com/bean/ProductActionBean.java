package com.bean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.dao.impl.ProductDAO;
import com.vo.Product;

@ManagedBean(name="productAction")
@RequestScoped
public class ProductActionBean {

	private int id;
	private String name;
	private float price;
	private String description;
	
	private List<Product> products;
	
	ProductDAO productDAO;
	
	public ProductActionBean() {
		// TODO Auto-generated constructor stub
		productDAO = new ProductDAO();
		getProducts();
	}
	
	
	public List<Product> getProducts() {
		
		products = productDAO.fetchProducts();
		
		return products;
	}
	
	public void addProduct(){
		System.out.println("ProductId   : "+id);
		System.out.println("ProductName : "+name);
		
		Product product = new Product(id, name, price, description);
		
		productDAO.addProduct(product);
		
		System.out.println();
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
