package com.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.dao.impl.ProductDAO;
import com.vo.Product;

@ManagedBean(name="productBean")
@RequestScoped
public class ProductBean {
	
	private int productId;
	
	private ProductDAO productDAO;
	
	private Product product;
	
	public ProductBean() {
		// TODO Auto-generated constructor stub
		productDAO = new ProductDAO(); 
	}
	
	public void searchProduct(){
		System.out.println("*******SearchProduct()*******");
		product = productDAO.fetchProductById(productId);
	}

	public int getProductId() {
		return productId;
	}
	
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public Product getProduct() {
		return product;
	}

}
