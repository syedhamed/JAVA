package com.mtc.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mtc.app.dao.IProductDAO;
import com.mtc.app.dao.ProductDAO;
import com.mtc.app.entity.Product;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();

		applicationContext.register(HibernateConfiguration.class);

		applicationContext.refresh();
		
		IProductDAO productDAO = (IProductDAO)applicationContext.getBean("productDAO");
		
		Product product = new Product(190,"Door Stopper","Stopper",10);
		
		productDAO.addProduct(product);
		
//		Product product = productDAO.fetchProductById(102);
//		
//		System.out.println("ProductName  : "+product.getName());
//		System.out.println("ProductPrice : "+product.getPrice());
		


	}

}
