package com.mtc.app.dao;

import java.util.List;

import com.mtc.app.entity.Product;

public interface IProductDAO {
	
	boolean addProduct(Product product);
	Product fetchProductById(int id);
	List<Product> fetchProducts();
	boolean deleteProduct(int id);
	boolean updateProduct(Product product);
	float fetchMaxPrice();
	void addProduct(List<Product> products);

}
