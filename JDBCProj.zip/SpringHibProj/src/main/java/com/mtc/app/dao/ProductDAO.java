package com.mtc.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mtc.app.entity.Product;

@Repository("productDAO")
public class ProductDAO implements IProductDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	//CMT(Container Manged Transactions)	
	@Transactional
	public boolean addProduct(Product product) {
	
		Session session = sessionFactory.getCurrentSession();	
		session.save(product);	
		return true;
	}

//BMT(Bean Managed Transactions)
//	public boolean addProduct(Product product) {
//		
//		Session session = sessionFactory.openSession();
//		
//		Transaction transaction = session.getTransaction();
//		
//		transaction.begin();
//		
//			session.save(product);
//			
//		transaction.commit();
//
//		return true;
//	}

	public Product fetchProductById(int id) {
		
		Session session = sessionFactory.openSession();
		
		Product product = (Product)session.get(Product.class,id);
		
		session.close();
		
		return product;
	}

	public List<Product> fetchProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteProduct(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public float fetchMaxPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addProduct(List<Product> products) {
		// TODO Auto-generated method stub
		
	}

}
