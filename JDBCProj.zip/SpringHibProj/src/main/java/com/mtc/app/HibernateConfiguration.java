package com.mtc.app;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import com.mtc.app.entity.Product;

@Configuration
@ImportResource("classpath:/META-INF/spring/app-context.xml")
public class HibernateConfiguration {

	@Value("#{dataSource}")
	private DataSource dataSource;

	@Bean("sessionFactory")
	public LocalSessionFactoryBean sessionFactoryBean() {
		Properties props = new Properties();
		props.put("hibernate.dialect","org.hibernate.dialect.MySQL5Dialect");
		props.put("hibernate.format_sql", "true");
		props.put("hibernate.show_sql","true");

		LocalSessionFactoryBean bean = new LocalSessionFactoryBean();
		//bean.setAnnotatedClasses(new Class[]{Item.class, Order.class});		
		bean.setAnnotatedClasses(new Class[]{Product.class});
		bean.setHibernateProperties(props);
		bean.setDataSource(this.dataSource);		
		return bean;
	}

	@Bean
	public HibernateTransactionManager transactionManager() {
		return new HibernateTransactionManager( sessionFactoryBean().getObject() );
	}

}
